package servlet;
import javax.servlet.*;
import javax.servlet.http.*;

import pkg.*;
import java.sql.*;
import java.util.*;
import java.io.*;
public class ViewMenuServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException{
		ArrayList menus;
		try	{			
			String sql="select * from MenuInfo";
			DBCon dbCon=new DBCon();//创建连接
			menus=dbCon.getMenuInfo(sql);//执行sql语句 返回结果集
			request.setAttribute("menus",menus);//将结果集放到request中
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("../index.jsp");//将结果发送到main.jsp显示
			requestDispatcher.forward(request,response);
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	public void doPost(HttpServletRequest request,
	                		HttpServletResponse response)
		throws IOException, ServletException{
	   doGet(request,response);
	}
}
