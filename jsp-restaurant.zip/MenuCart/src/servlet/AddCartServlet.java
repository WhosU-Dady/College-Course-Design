package servlet;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pkg.*;

public class AddCartServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {
		ArrayList total;
		ArrayList cart;
		ArrayList all;
		int allnum = 0;
		double sum = 0;

		request.setCharacterEncoding("gb2312");
		response.setContentType("text/html;charset=gb2312");

		HttpSession session = request.getSession();
		String userid = (String) session.getAttribute("userid");
		Cart c = new Cart();
		String menuID = request.getParameter("menuID");
		double price = Double.parseDouble(request.getParameter("price"));
		System.out.println("price:" + price);

		c.setMenuID(menuID);
		c.setPrice(price);

		DBCon con = new DBCon();
		if (request.getParameter("action").equals("add")) {
			int oldnum = con.getnum(userid, menuID);
			int updatenum = con.getnum(userid, menuID) + 1;
			double updatesum = updatenum * price;
			if (con.update(userid, menuID, updatenum, updatesum)) {
				cart = con.getcart(userid);
				request.setAttribute("ct", cart);
				all = con.getall(userid);
				Iterator it1 = all.iterator();
				while (it1.hasNext()) {
					sum = sum + (double) it1.next();
				}
				request.setAttribute("sum", sum);
				RequestDispatcher requestDispatcher = request
						.getRequestDispatcher("../ShowMenuCart.jsp");
				requestDispatcher.forward(request, response);
			}
		} else if (request.getParameter("action").equals("reduce")) {
			int oldnum = con.getnum(userid, menuID);
			if (oldnum > 1) {
				int updatenum = con.getnum(userid, menuID) - 1;
				double updatesum = updatenum * price;
				if (con.update(userid, menuID, updatenum, updatesum)) {
					cart = con.getcart(userid);
					request.setAttribute("ct", cart);
					all = con.getall(userid);
					Iterator it1 = all.iterator();
					while (it1.hasNext()) {
						sum = sum + (double) it1.next();
					}
					request.setAttribute("sum", sum);
					RequestDispatcher requestDispatcher = request
							.getRequestDispatcher("../ShowMenuCart.jsp");
					requestDispatcher.forward(request, response);
				}
			} else if (oldnum == 1) {

				cart = con.getcart(userid);
				request.setAttribute("ct", cart);
				all = con.getall(userid);
				Iterator it1 = all.iterator();
				while (it1.hasNext()) {
					sum = sum + (double) it1.next();
				}
				request.setAttribute("sum", sum);
				RequestDispatcher requestDispatcher = request
						.getRequestDispatcher("../ShowMenuCart.jsp");
				requestDispatcher.forward(request, response);

			}
		} else if (request.getParameter("action").equals("delete")) {
			if (!con.deletecart(userid, menuID)) {
				RequestDispatcher requestDispatcher = request
						.getRequestDispatcher("ShowCartServlet");
				requestDispatcher.forward(request, response);
			}
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {
		doGet(request, response);
	}
}
