package servlet;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pkg.MenuDB;
import pkg.DBCon;

public class ShowCartServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)
		    throws ServletException,java.io.IOException
		 {
		 ArrayList cart;
		 ArrayList price;
		 ArrayList total;
		 double sum = 0;
		 int allnum = 0;
		 
		 //request.setCharacterEncoding("gb2312");
		 request.setCharacterEncoding("utf-8");
		 //response.setContentType("text/html;charset=utf-8");
		 
		 HttpSession session = request.getSession();
		 String userid = (String) session.getAttribute("userid");
		 System.out.println("userid:"+userid);
		 String act = "act";
		 request.setAttribute("a", act);
		 DBCon con=new DBCon();
		
		 cart = con.getcart(userid);
		 request.setAttribute("ct",cart);
		 price = con.getall(userid);
		 Iterator it=price.iterator();
		 while(it.hasNext()){
			 sum = sum + (double)it.next();
		 }
		 request.setAttribute("sum", sum);
		 RequestDispatcher requestDispatcher = request.getRequestDispatcher("../ShowMenuCart.jsp");
		 requestDispatcher.forward(request,response);
		 } 
		  
		public void doPost(HttpServletRequest request,HttpServletResponse response)
		    throws ServletException,java.io.IOException
		 {
		 doGet(request,response);
		 }

}
