package servlet;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import pkg.DBCon;
import pkg.MenuDB;

public class GetCartServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)
		    throws ServletException,java.io.IOException
		 {
		 ArrayList total;
		 int allnum = 0;
		 //request.setCharacterEncoding("gb2312");
		 request.setCharacterEncoding("utf-8");
		 //response.setContentType("text/html;charset=utf-8");
		 
		 HttpSession session = request.getSession();   //得到HttpSession类型的对象
		 String userid = (String) session.getAttribute("userid");   //获得用户ID
		 
		 String menuID = request.getParameter("menuID");   //获得多个菜品编号  得到GET，POST方法提交过来的数据
		 System.out.println("menuID:"+menuID);
		 String menuName = new String(request.getParameter("menuName").getBytes("ISO8859-1"));
		 System.out.println("menuName:"+menuName);
		 double price = Double.parseDouble(request.getParameter("price"));
		 MenuDB md = new MenuDB();
		 
		 md.setMenuID(menuID);
		 
		 md.setMenuName(menuName);
		 md.setPrice(price);
		 
		 
		 
		 DBCon con=new DBCon();
		 total = con.getallnum(menuID);
		 Iterator it=total.iterator();   //集合total调用iterator方法，赋值给iterator接口的对象
		 while(it.hasNext()){
			 allnum = allnum + (int)it.next();
		 }
		 
		 if(con.getnum(userid,menuID) == 0){
			 con.addCart(userid, md, con.getnum(userid,menuID)+1, md.getPrice());
			 response.sendRedirect("../MenuCart.jsp");
		 }else{
			 int updatenum = con.getnum(userid, menuID)+1;
			 double updatesum = updatenum*price;
			 con.update( userid,menuID,updatenum,updatesum);
			 response.sendRedirect("../MenuCart.jsp");
		 }
		
			
		 }
	
		  
		public void doPost(HttpServletRequest request,HttpServletResponse response)
		    throws ServletException,java.io.IOException
		 {
		 doGet(request,response);
		 }

}
