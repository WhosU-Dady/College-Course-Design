package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pkg.DBCon;
import pkg.User;

/**
 * Servlet implementation class AddUserServlet1
 */
@WebServlet("/AddUserServlet1")
public class AddUserServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUserServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	request.setCharacterEncoding("gb2312");
	response.setContentType("text/html;charset=gb2312");
	User user=(User)request.getAttribute("user");

	//�������userInfo�в���һ����¼
	DBCon dbCon=new DBCon();
	if(dbCon.addUser(user)){
		System.out.println("�û����ݲ���ɹ�");
		
		//�����¼�󣬽�����ת��viewMessages_servlet�����ڲ�ѯ���ݿ����м�¼��Ȼ�����JSPҳ����ʾ
//		RequestDispatcher requestDispatcher = request.getRequestDispatcher("servlet/ViewUserServlet");
//		requestDispatcher.forward(request,response);		
	}else{
		response.sendRedirect("../reReg.jsp");
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
