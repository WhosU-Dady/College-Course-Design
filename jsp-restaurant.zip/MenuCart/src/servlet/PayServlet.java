package servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pkg.*;


public class PayServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		
		DBCon con = new DBCon();
		if(userid!=null && userid.length()>0
		&& password!=null && password.length()>0){
			userid=new String(userid.getBytes("ISO8859-1"));
			System.out.println(userid);
			System.out.println(password);
			if(con.queryUser(userid,password)){
				if (!con.FreeMenuCart(userid)) {  //清空购物车
					
					
					response.sendRedirect("../PayOK.jsp");
					System.out.println("");
				}
			}else{
				response.sendRedirect("../PayError.jsp");
				System.out.println("PayError!");
			}
		}else{
			response.sendRedirect("../PayError.jsp");
			System.out.println("PayError!");
		}
	}
}
