package servlet;

import pkg.Menu;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pkg.DBCon;

public class MenuOperator extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		String MenuID = request.getParameter("MenuID");
		String MenuName = request.getParameter("MenuName");
		String MenuClass = request.getParameter("menuClass");
		String Togethers = request.getParameter("Togethers");
		String Taste = request.getParameter("Taste");
		String MakingWay = request.getParameter("MakingWay");
		String Price = request.getParameter("Price");
		
		DBCon con = new DBCon();
		if (action != null
			&& MenuID != null
			&& MenuName != null
			&& MenuClass != null
			&& Togethers != null
			&& Taste != null
			&& MakingWay != null
			&& Price != null) {
			action = new String(action.getBytes("ISO-8859-1"));
			MenuID = new String(MenuID.getBytes("ISO-8859-1"));
			MenuName = new String(MenuName.getBytes("ISO-8859-1"), "GB2312");
			MenuClass = new String(MenuClass.getBytes("ISO-8859-1"), "GB2312");
			Togethers = new String(Togethers.getBytes("ISO-8859-1"), "GB2312");
			Taste = new String(Taste.getBytes("ISO-8859-1"), "GB2312");
			MakingWay = new String(MakingWay.getBytes("ISO-8859-1"), "GB2312");
			Price = new String(Price.getBytes("ISO-8859-1"));
			Menu menu = new Menu();
			menu.setMenuID(MenuID);
			menu.setMenuName(MenuName);
			menu.setMenuClass(MenuClass);
			menu.setTogethers(Togethers);
			menu.setTaste(Taste);
			menu.setMakingWay(MakingWay);
			menu.setPrice(Double.valueOf(Price));
			con.OpeartorMenu(menu, action.equals("add"));
			response.sendRedirect("../RootRequest.jsp");
		}else{
			response.sendRedirect("../RootRequest.jsp");
		}
	}
}
