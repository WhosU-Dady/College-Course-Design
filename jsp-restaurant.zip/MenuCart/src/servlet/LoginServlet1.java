package servlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pkg.*;

public class LoginServlet1 extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		
		if(userid!=null && userid.length()>0
		&& password!=null && password.length()>0){
			userid=new String(userid.getBytes("ISO8859-1"));
			if(DBCon.queryUser(userid,password)){
				HttpSession session=request.getSession();
				session.setAttribute("userid",userid);
				System.out.println(userid);
				response.sendRedirect("../loginInfo.jsp");
				System.out.println("");
			}else{
				response.sendRedirect("../LoginError.jsp");
				System.out.println("");
			}
		}else{
			response.sendRedirect("../LoginError.jsp");
			System.out.println("���ݲ�ѯʧ�ܣ�!");
		}
	}

}




