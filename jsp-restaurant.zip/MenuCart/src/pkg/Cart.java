package pkg;

public class Cart {
	private String userid;
	private String menuID;
	private String menuName;
	private String menuClass;
	private String togethers;
	private String taste;
	private double price;
	private String makingWay;
	private int num;
	private double allprice;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getMenuID() {
		return menuID;
	}
	public void setMenuID(String menuID) {
		this.menuID = menuID;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuClass() {
		return menuClass;
	}
	public void setMenuClass(String menuClass) {
		this.menuClass = menuClass;
	}
	public String getTogethers() {
		return togethers;
	}
	public void setTogethers(String togethers) {
		this.togethers = togethers;
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getMakingWay() {
		return makingWay;
	}
	public void setMakingWay(String makingWay) {
		this.makingWay = makingWay;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public double getAllprice() {
		return allprice;
	}
	public void setAllprice(double allprice) {
		this.allprice = allprice;
	}

	



}
