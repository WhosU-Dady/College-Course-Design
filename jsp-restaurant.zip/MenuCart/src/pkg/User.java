package pkg;
import java.util.*;
public class User {
	private String userid;
	private String password;
	private String email;
	private String secQuestion;
	private String secAnswer;
	private HashMap errors=new HashMap();
	
	public User(){
		userid="";
		password="";
		email="";
		secQuestion="";
		secAnswer="";
	}
	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSecQuestion() {
		return secQuestion;
	}

	public void setSecQuestion(String secQuestion) {
		this.secQuestion = secQuestion;
	}

	public String getSecAnswer() {
		return secAnswer;
	}

	public void setSecAnswer(String secAnswer) {
		this.secAnswer = secAnswer;
	}
	public String getErrors(String key) {
		String value=(String)errors.get(key);
		if(value==null)
			return "";
		else
			return value;
	}

	public void setErrors(String key,String value) {
		errors.put(key, value);
	}

//	public void setErrors(String key,String value) {
//		errors.put(key, value);
//	}
//	public String getErrors(String key) {
//		String value=(String)errors.get(key);
//		if(value==null)
//			return "";
//		else
//			return value;
//	}

	public boolean validate(){
		boolean blnOk=true;
		if(userid==null || userid.length()==0){
			setErrors("userName","用户名不能为空");
			blnOk=false;
		}
		if(password==null || password.length()==0){
			setErrors("password","密码不能为空");
			blnOk=false;
		}else if(password.length()<6) {
			setErrors("password","密码不能小于6位");
			blnOk=false;
		}
		if(email==null || email.length()==0){
			setErrors("email","邮件不能为空");
			blnOk=false;
		}else if(email.indexOf("@")==-1 ||email.indexOf(".")==-1 ) {
			setErrors("email","邮件格式不正确");
			blnOk=false;
		}
		if(secQuestion==null || secQuestion.length()==0){
			setErrors("secQuestion","密保问题不能为空");
			blnOk=false;
		}
		if(secAnswer==null || secAnswer.length()==0){
			setErrors("secAnswer","密保答案不能为空");
			blnOk=false;
		}
		return blnOk;
	}
}