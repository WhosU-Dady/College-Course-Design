package pkg;

import java.util.HashMap;

public class MenuDB {
	private String menuID;
	private String menuName;
	private double price;
	private String menuClass;
	private String togethers;
	private String taste;
	private String makingWay;
	

	
	public String getMenuID() {
		return menuID;
	}
	public void setMenuID(String menuID) {
		this.menuID = menuID;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getMenuClass() {
		return menuClass;
	}
	public void setMenuClass(String menuClass) {
		this.menuClass = menuClass;
	}
	public String getTogethers() {
		return togethers;
	}
	public void setTogethers(String togethers) {
		this.togethers = togethers;
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public String getMakingWay() {
		return makingWay;
	}
	public void setMakingWay(String makingWay) {
		this.makingWay = makingWay;
	}
	public HashMap getErrors() {
		return errors;
	}
	public void setErrors(HashMap errors) {
		this.errors = errors;
	}
	private HashMap errors=new HashMap();
	
	
}
