package pkg;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import pkg.*;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DBCon{
	public  DBCon(){

	}
	public static Connection JavaCon(){
		try {
			//连接数据库
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url="jdbc:sqlserver://localhost:1433; DatabaseName=msdb";
			Connection conn=DriverManager.getConnection(url,"fuqin","123");
			System.out.println("数据库连接成功");
			return conn;
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("数据库连接失败");
			return null;
		}
	}


	
	
	//获得菜品信息
public ArrayList getMenuInfo(String sql){
		Connection conn=JavaCon();//调用
		ArrayList menus=new ArrayList();//新建数组
		try{
			Statement stm=conn.createStatement();
			//鏌ヨ		
			ResultSet rs=stm.executeQuery(sql);	
			if(rs!=null){
				while(rs.next()){//遍历数据
					
					String menuID=rs.getString(1);
					String menuName=rs.getString(2);
					String menuClass=rs.getString(3);
					String togethers=rs.getString(4);
					String taste=rs.getString(5);
					double price=Double.parseDouble(rs.getString(6));
					String makingWay=rs.getString(7);							
					Menu m=new Menu();				
					m.setMenuID(menuID);					
					m.setMenuName(menuName);
					m.setMenuClass(menuClass);
					m.setTogethers(togethers);
					m.setTaste(taste);				
					m.setPrice(price);
					m.setMakingWay(makingWay);										
					menus.add(m);
				}
				rs.close();
				stm.close();
				conn.close();
				return menus;
			}else{
				return null;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}


public boolean addUser(User user){
	try{
		Connection conn=JavaCon();
		
		//用于向表users中插入一条记录
		PreparedStatement pstm=conn.prepareStatement("insert into userInfo values(?,?,?,?,?);");
	    pstm.setString(1,user.getUserid());
		pstm.setString(2,user.getPassword());
		pstm.setString(3,user.getEmail());
		pstm.setString(4,user.getSecQuestion());
		pstm.setString(5,user.getSecAnswer());
		int r=pstm.executeUpdate();
		pstm.close();
		conn.close();
		if(r>0){
			return true;
		}else{
			return false;
		}
	}catch(Exception ex){
		ex.printStackTrace();
		return false;
	}
}

//获得用户表信息
public ArrayList getUserInfo(){
	Connection conn=JavaCon();
	ArrayList users=new ArrayList();
	try{
		Statement stm=conn.createStatement();
		//查询表message中有几条记录
		ResultSet rs=stm.executeQuery("select * from userInfo");		
		if(rs!=null){
			while(rs.next()){//遍历所有的记录
				String userid=rs.getString(1);
				String password=rs.getString(2);
				String email=rs.getString(3);
				String secQuestion=rs.getString(4);
				String secAnswer=rs.getString(5);
				
				//创建UserBean对象，用于存储数据库中的数据
				User u=new User();
				u.setUserid(userid);
				u.setPassword(password);
				u.setEmail(email);
				u.setSecQuestion(secQuestion);
				 u.setSecAnswer(secAnswer);
				users.add(u);	
			}
			rs.close();
			stm.close();
			conn.close();
			return users;
		}else{
			return null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}
}


//查询数据方法
public static  boolean queryUser(String userid,String password){
	try{
		String sql="select * from userInfo where userid='"+userid+
		"' and password='"+password+"'";
		Connection conn=JavaCon();
		Statement stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery(sql);
		System.out.println(userid);
		if(rs!=null ){
			rs.next();
			if(rs.getString(1).equals(userid) &&
					rs.getString(2).equals(password)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}catch(Exception ex){
		ex.printStackTrace();
		return false;
	}
}




//添加购物车
public boolean addCart(String userid, MenuDB mb, int num, double sum){
	try{
		Connection conn=JavaCon();
		//添加商品进购物车并获得数据存进购物车表
		PreparedStatement pstm=conn.prepareStatement("insert into cart values(?,?,?,?,?,?);");
	    pstm.setString(1,userid);
		pstm.setString(2,mb.getMenuID());
		pstm.setString(3,mb.getMenuName());
		pstm.setDouble(4,mb.getPrice());
		pstm.setInt(5,num);
		pstm.setDouble(6,sum);
		int r=pstm.executeUpdate();
		pstm.close();
		conn.close();
		if(r>0){
			return true;
		}else{
			return false;
		}
	}catch(Exception ex){
		ex.printStackTrace();
		return false;
	}
}

// 管理员菜单操作
public boolean OpeartorMenu(Menu menu, boolean IsAdd){
	try{
		Connection conn=JavaCon();
		
		PreparedStatement pstm = null;
		if (IsAdd) {
			pstm = conn.prepareStatement("insert into MenuInfo values(?,?,?,?,?,?,?);");
			pstm.setString(1,menu.getMenuID());
			pstm.setString(2,menu.getMenuName());
			pstm.setString(3,menu.getMenuClass());
			pstm.setString(4,menu.getTogethers());
			pstm.setString(5,menu.getTaste());
			pstm.setDouble(6,menu.getPrice());
			pstm.setString(7,menu.getMakingWay());
		} else {
			pstm = conn.prepareStatement("delete from MenuInfo where menuID=?;");
			pstm.setString(1,menu.getMenuID());
		}
		
		int r=pstm.executeUpdate();
		pstm.close();
		conn.close();
		if(r>0){
			return true;
		}else{
			return false;
		}
	}catch(Exception ex){
		ex.printStackTrace();
		return false;
	}
}


//查询购物车
public ArrayList getcart(String userid){
	System.out.println("uid:"+userid);
	Connection conn=JavaCon();
	ArrayList cart=new ArrayList();
	try{
		String sql="select * from cart where userid='"+userid+"'";
		Statement stm=conn.createStatement();
		
		ResultSet rs=stm.executeQuery(sql);		
		if(rs!=null){
			while(rs.next()){//遍历信息
				String uid=rs.getString(1);
				String menuID=rs.getString(2);
				String menuName=rs.getString(3);			
				double price=rs.getDouble(4);
				int num=rs.getInt(5);
				double allprice=rs.getDouble(6);
				
				//显示信息
				Cart c=new Cart();
				c.setUserid(uid);
				c.setMenuID(menuID);
				c.setMenuName(menuName);				
				c.setPrice(price);
				c.setNum(num);
				c.setAllprice(allprice);
				cart.add(c);	
			}
			rs.close();
			stm.close();
			conn.close();
			return cart;
		}else{
			return null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}
}



//获得菜品数量
public int getnum(String userid,String menuID){
	Connection conn=JavaCon();
	int a = 0;
	try{
		String sql="select * from cart where userid='"+userid+
		"' and menuID='"+menuID+"'";
		Statement stm=conn.createStatement();
		
		ResultSet rs=stm.executeQuery(sql);		
		if(rs!=null){
			while(rs.next()){
				int num=rs.getInt(5);			
				Cart t=new Cart();
				t.setNum(num);
				a = t.getNum();	
			}
			rs.close();
			stm.close();
			conn.close();
			return a;
		}else{
			return (Integer) null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return (Integer) null;
	}
}


//修改购物车信息
public boolean update(String userid,String menuID,int num,double total){
	Connection conn=JavaCon();
	try{
		String sql = "update cart set num = '"+num+ "'where userid = '" +userid+"'and menuID='"+menuID+"'";
		String sql1 = "update cart set total = '"+ total + "'where userid ='" + userid +"'and menuID='"+menuID+"'";
		Statement stmt = conn.createStatement();
		stmt.executeUpdate(sql);
		stmt.executeUpdate(sql1);
		int r=stmt.executeUpdate(sql);
		stmt.close();
		conn.close();
		if(r>0){
			return true;
		}else{
			return false;
		}
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
}

public ArrayList getall(String userid){
	Connection conn = JavaCon();
	ArrayList tickets=new ArrayList();
	try{
		
		Statement stm = conn.createStatement();
		String sql = "select total from cart where userid = '"+userid+"'";
		ResultSet rs=stm.executeQuery(sql);	
		if(rs!=null){
			while(rs.next()){
			double sum=rs.getDouble(1);
			tickets.add(sum);	
			}
			rs.close();
			stm.close();
			conn.close();
			return tickets;
		}else{
			return  null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}
}

public ArrayList getallnum(String menuID){
	Connection conn=JavaCon();
	ArrayList allnum=new ArrayList();
	try{
		String sql="select num from cart where menuID='"+menuID+"'";
		Statement stm=conn.createStatement();
		
		ResultSet rs=stm.executeQuery(sql);		
		if(rs!=null){
			while(rs.next()){
				int num = rs.getInt(1);
				
			
				allnum.add(num);
			}
			rs.close();
			stm.close();
			conn.close();
			return allnum;
		}else{
			return null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}
}


public boolean deletecart(String userid,String menuID){
	Connection conn=JavaCon();
	try{
		String sql = "delete from cart where userid='"+userid+"'and menuID='"+menuID+"'";
		Statement stmt = conn.createStatement();
		stmt.executeUpdate(sql);
		int r=stmt.executeUpdate(sql);
		stmt.close();
		conn.close();
		if(r>0){
			return true;
		}else{
			return false;
		}
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
}


public boolean deleteshoppingcart(String userid){
	Connection conn=JavaCon();
	try{
		String sql = "delete from cart where userid='"+userid+"'";
		Statement stmt = conn.createStatement();
		stmt.executeUpdate(sql);
		int r=stmt.executeUpdate(sql);
		stmt.close();
		conn.close();
		if(r>0){
			return true;
		}else{
			return false;
		}
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
}




public ArrayList getmenuID(String userid){
	Connection conn = JavaCon();
	ArrayList menuID = new ArrayList();
	try{
		
		Statement stm = conn.createStatement();
		String sql = "select menuID from cart where userid = '"+userid+"'";
		ResultSet rs=stm.executeQuery(sql);	
		if(rs!=null){
			while(rs.next()){//遍历以下信息
			String id=rs.getString(1);
			menuID.add(menuID);	
			}
			rs.close();
			stm.close();
			conn.close();
			return menuID;
		}else{
			return null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}
}

public String getusername(String userid){
	Connection conn = JavaCon();
	try{
		String name = "";
		Statement stm = conn.createStatement();
		String sql = "select username from userinfo where userid = '"+userid+"'";
		ResultSet rs=stm.executeQuery(sql);	
		if(rs!=null){
			while(rs.next()){
			name=rs.getString(1);
			}
			rs.close();
			stm.close();
			conn.close();
			return name;
		}else{
			return null;
		}
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}
}
//清空购物车
public  boolean FreeMenuCart(String userid){
	Connection conn=JavaCon();
	try{
		String sql = "delete from cart where userid='"+userid+"'";
		Statement stmt = conn.createStatement();
		stmt.executeUpdate(sql);
		int r=stmt.executeUpdate(sql);
		stmt.close();
		conn.close();
		if(r<=0){
			return false;
		}
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
	return true;
}

//删除菜单
public boolean delemenu(String menuid){
	Connection conn=JavaCon();
	try{
		String sql = "delete from menu where menuid='"+menuid+"'";
		Statement stmt = conn.createStatement();
		stmt.executeUpdate(sql);
		int r=stmt.executeUpdate(sql);
		stmt.close();
		conn.close();
		if(r<=0){
			return false;
		}
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
	return true;
}
}

		
			
		