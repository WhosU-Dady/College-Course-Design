package pkg;


public class Menu{
	private String menuID;  //菜品ID
	private String menuName;//菜品名字
	private String menuClass;//菜品类
	private String togethers;//材料
	private String taste;//口味	
	private double price;//价格
	private String makingWay;//做法
    

	
	public Menu(){
		menuID="";
		menuName="";
		menuClass="";
		togethers="";
		taste="";
		price=0.0d;
		makingWay="";
	    
	}



	public String getMenuID() {
		return menuID;
	}



	public void setMenuID(String menuID) {
		this.menuID = menuID;
	}



	public String getMenuName() {
		return menuName;
	}



	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}



	public String getMenuClass() {
		return menuClass;
	}



	public void setMenuClass(String menuClass) {
		this.menuClass = menuClass;
	}



	public String getTogethers() {
		return togethers;
	}



	public void setTogethers(String togethers) {
		this.togethers = togethers;
	}



	public String getTaste() {
		return taste;
	}



	public void setTaste(String taste) {
		this.taste = taste;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public String getMakingWay() {
		return makingWay;
	}



	public void setMakingWay(String makingWay) {
		this.makingWay = makingWay;
	
	
	

}
}