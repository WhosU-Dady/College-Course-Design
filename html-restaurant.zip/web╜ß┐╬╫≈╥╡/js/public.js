// 添加对load的监听事件
window.addEventListener("load", function() {
    $('footer')[0].innerHTML = "Copyright &copy; "+(new Date().getFullYear())+" CSG";
    if ($('#buypake') != null) {
        $('#buypake').onclick = function() {
            window.location.href = "buypake.html";
        }
    }
}, true);

const message = (function() {

    var Message = new Object;

    var main = document.createElement("div");
    main.setAttribute("id", "message");

    var insertObject = document.createElement("div");
    var insertTemp = insertObject;

    // 初始化
    window.addEventListener("load", function() {
        document.body.appendChild(main);
         main.appendChild(insertObject);
    }, true);

    function show(str, type) {
        var notice = document.createElement("div");
        notice.setAttribute("class", "notice");
        notice.setAttribute("type", type);
        notice.innerHTML = str;
        if (main.childNodes.length == 1) {
            insertTemp = insertObject;
        }
        main.insertBefore(notice, insertTemp);
        insertTemp = notice;
        setTimeout(function() {
            notice.style.opacity = 1;
        }, 50);
        setTimeout(function() {
            notice.style.opacity = 0;
            setTimeout(function() {
                main.removeChild(notice);
            }, 250);
        }, 3000);
    }

    Message.error = function(str) {
        show(str, "error");
    }

    Message.tip = function(str) {
        show(str, "tip");
    }

    Message.warn = function(str) {
        show(str, "warn");
    }

    return Message;
})();