Storage.prototype.getObject = function(key) {
    var ret = this.getItem(key);

	// JSON.parse强制字符串转json
    return ret ? JSON.parse(ret.uncompile()) : null;
}

Storage.prototype.setObject = function(key, json) {
	// JSON.stringify强制json转字符串
    this.setItem(key, JSON.stringify(json).compile());

    return;
}

Storage.prototype.removeObject = function(key) {
    this.removeItem(key);

    return;
}

// 字符串加密
String.prototype.compile = function() {
    var ret = String.fromCharCode(this.charCodeAt(0) + this.length);
    for (var i = 1; i < this.length; ++i) {
        ret += String.fromCharCode(this.charCodeAt(i) + this.charCodeAt(i - 1));
    }
    return escape(ret);
}

// 字符串解密
String.prototype.uncompile = function() {
    var str = unescape(this);
    var ret = String.fromCharCode(str.charCodeAt(0) - str.length);
    for(var i = 1; i < str.length; ++i) {
        ret += String.fromCharCode(str.charCodeAt(i) - ret.charCodeAt(i - 1));
    }
    return ret;
}