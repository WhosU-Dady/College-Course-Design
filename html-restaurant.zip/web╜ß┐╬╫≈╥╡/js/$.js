//封装简单的jq方法
function $(str, object) {
    if (!str) {
        return str;
    }

    if (!object) {
        object = document;
    }

    if (str.indexOf('.') != -1) {
        return object.querySelectorAll(str);
    }

    if (str[0] == '#') {
        return object.getElementById(str.replace('#', ''));
    }

    return object.getElementsByTagName(str);
}

Object.prototype.$ = function(str, object) {
    if (object == null) {
        return $(str, this);
    }
    return $(str, object);
}

//返回的节点数组中搜索
Function.prototype.find = Object.prototype.find = function(str) {
    var child = this.childNodes;
    var ret = new Array();
    var This = this;

    if (This.length == null) {
        This = new Array(this);
    }

    for (var i = This.length - 1; i >= 0; --i) {
        ret.push(This[i].$(str, This[i]));
    }
    return ret;
}